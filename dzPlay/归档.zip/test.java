package dzPlay;


public class test {
	public static void main(String[] args) {
		From play=new From();
		play.playGame();
	}
}
